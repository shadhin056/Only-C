//Number Theorem
//nt - base conversation
//Xplosive
//++,

#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <stack>
#include <list>
#include <map>
#include <fstream>
#include <numeric>
#include <iterator>
#include <bitset>
#include <utility>
#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <conio.h>

#define READ(file) freopen(file, "r", stdin);
#define WRITE(file) freopen(file, "w", stdout);
#define PI acos(-1.0)


#define MAX 1100000

using namespace std;

void print_vector(vector<int> v);
void print_vector(vector<char> v);
void print_array(int* a, int l);



vector <int> decToBinary(long n)
{
    vector <int> v;
    if(n==0)
    {
        v.push_back(0);
        return v;
    }

    while(n)
    {
        v.push_back(n%2);
        n/=2;
    }
    reverse(v.begin(),v.end());
    return v;
}


long binaryToDec(long n)
{
    int r,i=0;
    long d=0;
    while(n)
    {
        r = n%10;
        d+=(pow(2,i)*r);
        n/=10;
        i++;
    }
    return d;

}


vector <int> decToBaseNegTwo(long n)
{
    vector <int> v;
    if(n==0)
    {
        v.push_back(0);
        return v;
    }

    cout << "n=" << n << endl;
    while(n)
    {
        //if(n<0) n = -1*n;
        int d = abs(n%2);



        cout << "n= " << n << setw(10) << " d= " << d <<endl;;
        //v.push_back(abs(d));
        if(d==0)
        {
            n-=1;
        }
        n = n/(-2);

        getch();
    }
    reverse(v.begin(),v.end());
    return v;
}


int main()
{
    //READ("input.txt");
    //WRITE("output.txt");

    vector <int> v;
    vector <char> vch;
    int n=34;




    while(1)
    {
        //cin >> n;
        //v=decToBinary(n);
        //print_vector(v);

        //cout << binaryToDec(n) << endl;
        v = decToBaseNegTwo(n);
        print_vector(v);

        //cout << n%(2) << endl;



        cout << endl;

    }



    return 0;
}

void print_array(int* a, int l)
{
    for(int i= 0; i<l; i++)
        cout << a[i] << " ";

    cout << endl;
}

void print_vector(vector<int> v)
{
    for(int i=0; i<v.size(); i++)
        cout << v[i] << " ";

    cout << endl;
}

void print_vector(vector<char> v)
{
    for(int i=0; i<v.size(); i++)
        cout << v[i] << " ";

    cout << endl;
}




/*



*/
