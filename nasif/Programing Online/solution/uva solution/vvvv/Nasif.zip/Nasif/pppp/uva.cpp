//stl
//673 - parentheses balance
//Xplosive
//

#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <vector>
#include <set>
#include <queue>
#include <stack>
#include <list>
#include <map>
#include <fstream>
#include <numeric>
#include <iterator>
#include <bitset>
#include <utility>
#include <cstdio>
#include <cstdlib>
#include <cctype>
#include <cmath>
#include <cstring>
#include <ctime>
#include <iomanip>
#include <conio.h>

#define READ(file) freopen(file, "r", stdin);
#define WRITE(file) freopen(file, "w", stdout);
#define PI acos(-1.0)


#define MAX 1100000

using namespace std;

void print_vector(vector<int> v);
void print_vector(vector<char> v);
void print_array(int* a, int l);
void print_stack(stack<char>st);


int main()
{
    //READ("input.txt");
    //WRITE("output.txt");

    int t, tt;
    cin >> tt;



    string s;

    for(t=1; t<=tt; t++)
    {
        stack<char> st;
        cin >> s;

        for(int i=0; i<s.size(); i++)
        {
            if(s[i]==')'|| s[i]=='}'|| s[i]==']')
            {
                if(st.top()== s[i])
                {
                    st.pop();
                }
                else
                {
                    break;
                }
            }
            else
            {
                st.push(s[i]);
            }
            //print_stack(st);
        }

        print_stack(st);

        if(st.empty())
            cout << "Yes" << endl;
        else
            cout << "No" << endl;

    }


    return 0;
}

void print_array(int* a, int l)
{
    for(int i= 0; i<l; i++)
        cout << a[i] << " ";

    cout << endl;
}

void print_stack(stack<char> st)
{
    while(!st.empty())
    {
        cout << st.top() << " ";
        st.pop();

    }
    cout << endl;
}

void print_vector(vector<int> v)
{
    for(int i=0; i<v.size(); i++)
        cout << v[i] << "";

    cout << endl;
}

void print_vector(vector<char> v)
{
    for(int i=0; i<v.size(); i++)
        cout << v[i] << " ";

    cout << endl;
}




/*



*/
